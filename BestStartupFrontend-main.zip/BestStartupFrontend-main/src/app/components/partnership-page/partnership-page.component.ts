import { Component } from '@angular/core';

@Component({
  selector: 'app-partnership-page',
  templateUrl: './partnership-page.component.html',
  styleUrls: ['./partnership-page.component.css']
})
export class PartnershipPageComponent {

}
